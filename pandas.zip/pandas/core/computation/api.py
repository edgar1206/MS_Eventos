__all__ = ["eval"]
from pandas.core.computation.eval import eval
